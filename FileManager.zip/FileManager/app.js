// imports
const express = require('express')
const app = express()
const port = 3000
const fs = require('fs')
const utils = require('./utils')
const bodyParser = require('body-parser')
var path = require('path');


let urlencodedParser = bodyParser.urlencoded({ extended: true })

// Static Files
app.use(express.static('public'))
app.use('/css', express.static(__dirname + 'public/css'))
app.use('/js', express.static(__dirname + 'public/js'))
app.use('/img', express.static(__dirname + 'public/img'))

// Set Views
app.set('views', 'public/views')
app.set('view engine', 'ejs')

// Get folder & file 
app.get('/data', (req, res) => {
    let fileManager = []
    let folderManager = []
    const files = fs.readdirSync('public/data')
        for(i = 0; i < files.length; i++){
            const stats = fs.statSync('public/data/' + `${files[i]}`)
            if(stats.isFile()){
                let objectManager = {}
                objectManager["name"] = utils.getFileName(files[i], stats.isFile())
                objectManager["extension"] = utils.getExtensionName(files[i])
                objectManager["size"] = utils.getFileWeight(files[i])
                fileManager.push(objectManager)
            }
        }

    const folder = fs.readdirSync('public/data')
    for(i = 0; i < folder.length; i++){
        const stats = fs.statSync('public/data/' + `${folder[i]}`)
        if(stats.isDirectory()){
            let objectManager = {}
            objectManager["name"] = utils.getFileName(folder[i], stats.isFile())
            folderManager.push(objectManager)
        }
    }
    res.render('index', {fileManager, folderManager})
})

//Handle folder operation
//Check if folder already exist
app.post('/folder', urlencodedParser, (req, res) => {
    if(fs.existsSync(`public/data/${req.body.folderName}`)){
        console.log('Le dossier existe déjà')
    }else{
        fs.mkdir("public/data/" + `${req.body.folderName}`, err => {
            if(err)
                throw err;
        })
    }
    res.redirect('http://localhost:3000/data/');
})

// Remove all the file before removing folder
app.post('/removefolder', urlencodedParser, (req, res) => {
    fs.readdirSync(`public/data/${req.body.removefolder}`).forEach(filename => {
        fs.unlinkSync(`public/data/${req.body.removefolder}/${filename}`)
    })

    fs.rmdir(`public/data/${req.body.removefolder}`, err => {
        if(err)
            throw err;
    })
    res.redirect('http://localhost:3000/data/');
})

// Handle file operation
// Check if file name is empty
// Check if file name have extension if not set .txt by default
app.post('/file', urlencodedParser, (req, res) => {
    if(req.body.fileName == ""){
        console.log("File name is empty")
    }else if(!req.body.fileName.includes(".")){
        fs.writeFile(`public/data/${req.body.fileName}` + ".txt", '', err => {
            if(err)
                throw err;
            console.log('Fichier créer')
        })
    }else{
        fs.writeFile(`public/data/${req.body.fileName}`, '', err => {
            if(err)
                throw err;
            console.log('Fichier créer')
        })
    }

    res.redirect('http://localhost:3000/data/');
})

app.post('/removefile', urlencodedParser, (req, res) =>{
    fs.unlinkSync(`public/data/${req.body.removefile}`)
    res.redirect('http://localhost:3000/data/');
})

// Listen on port 3000
app.listen(port, () => console.info(`Listening on port ${port}`))

