const fs = require('fs')

// Handle file and folder name
let getFileName = function(string, isFile){
    let fileName = ""
    if(isFile && string.includes(".")){
        fileName = string.substring(0, string.indexOf('.'))
    }else{
        fileName = string
    }
    return fileName
}

let getExtensionName = function(string){
    if(string.includes(".")){
        let fileExtensionName = "." + string.split('.')[1]
        return fileExtensionName
    }else{
        let fileExtensionName = string.split('.')[1]
        return fileExtensionName
    }
}

let getFileWeight = function(string) {    
    var stats = fs.statSync(`public/data/${string}`)
    var fileSizeInBytes = stats["size"];
    var fileSizeInMegaBytes = fileSizeInBytes / 1000000.0
    return fileSizeInMegaBytes
}

module.exports = {
    getFileName,
    getExtensionName,
    getFileWeight
}