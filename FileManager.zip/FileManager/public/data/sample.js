let btnFormFolderBack = document.getElementById("form_folder_back")
let formAddFolder = document.getElementById("form_add_folder")
let btnAddfolder = document.getElementById("add_folder")
let btnValidFolder = document.getElementById("form_valid_folder")

let btnFormFileBack = document.getElementById("form_file_back")
let formAddFile = document.getElementById("form_add_file")
let btnAddFile = document.getElementById("add_file")
let btnValidFile = document.getElementById("form_valid_file")

// Check if input is empty on validate folder name's
btnValidFolder.addEventListener("click", function(){
    let inputFolder = document.getElementById("input_folder").value
    if(inputFolder == ""){
        alert("Veuillez saisir un nom pour votre dossier")
        return false
    }else{
        return
    }
})

// Handle behavior component on button click
btnAddFile.addEventListener("click", function(){
    formAddFile.style.display = "flex"
});

btnFormFileBack.addEventListener("click", function(){
    formAddFile.style.display = "none"
});

btnAddfolder.addEventListener("click", function(){
    formAddFolder.style.display = "flex"
});

btnFormFolderBack.addEventListener("click", function(){
    formAddFolder.style.display = "none"
});
